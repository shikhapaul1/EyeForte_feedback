<h1>Hello {{$data['name']}}</h1>

<p>Thanks For Giving Your Feedback,Thank you so much for your review, we will take care better in your next visit.</p>