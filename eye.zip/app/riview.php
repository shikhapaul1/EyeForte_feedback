<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class riview extends Model
{
   protected $guarded = [];
}
