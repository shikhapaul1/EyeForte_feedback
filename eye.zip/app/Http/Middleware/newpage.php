<?php

namespace App\Http\Middleware;

use Auth;
use Closure;

class newpage
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
       if(!Auth::guard('login')->check())
        {
            return redirect()->route('Login');
        }
        return $next($request);
    }
}
