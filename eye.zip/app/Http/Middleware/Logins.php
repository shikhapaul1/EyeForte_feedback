<?php

namespace App\Http\Middleware;

use Closure;
use Auth;

class Logins
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
           if(!Auth::guard('login')->check())
        {
            return redirect()->route('Login');
        }
        return $next($request);
    }
}
