<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use App\riview;
use App\login;
use App\Mail\feedback;
use App\registration;

class feedbackController extends Controller
{
    // public function feedback()
    // {
    // 	return view('Feedback.Feedback_Form');
    // }

    public function feedback_submit(Request $request,$name,$bill,$mobile,$email)
    {
    	$request->validate([
    		'name' => 'required',
    		'bill' => 'required',
    		'mobile' => 'required',
    		'email' => 'required',
    		'Social_Media' => 'required',
    		'satisfied' => 'required',
    		'Very' => 'required',
    		'Good' => 'required',
    		'Yes' => 'required',
    		'Every' => 'required',
    		'No' => 'required',
    		'selection' => 'required',
    		'shopping' => 'required',
    		'satisfy' => 'required',
    		'Once' => 'required',
    		'Comments' => 'required',
    		'Commentsssss' => 'required'
    	]);
    	$create = riview::create($request->all());


    	$data = array(
    		'name' => $request->name,
    		'Comments' => $request->Comments
    	);

    	// Mail::to( $request->email)->send(new Feedback($data));

    	return back()->with('success',"Thank you For Sending Your Feedback");

    	// return redirect()->route('Feedback_Form')->with('success',"Successfully Submitted Your Review");
    	
    }


    public function registration()
    {
    	return view('Registration.registration');
    }

    public function registration_submit(Request $request)
    {
        $request->validate([

            'name' =>'required',
            'number' =>'required',
            'email' =>'required',
            'password' =>'required',
        ]);

        $request['password'] = Hash::make($request['password']);

        $create = registration::create($request->all());
        return redirect()->route('Login');
    }

    public function Login()
    {
        return view('Login.login');
    }

    public function Login_submit(Request $request)

         {
     $request->validate([
        'email' => 'required',
        'password' => 'required',
        ]);
 
        $credentials = $request->only('email', 'password');
        if (Auth::guard('login')->attempt($credentials)) {

          //echo $request->ip();
            return redirect()->route('dashboard_version_1');
        }
        else
        {
          return redirect('login')->with('error','Username or Password is Incorrect');
        }

    }

    public function Logout()
    {
        Auth::guard('login')->logout();

        return redirect()->route('Login');
    }

    public function __construct()
    {
        $this->middleware('Logins', ['except' => ['Login', 'Login_submit','feedback','feedback_submit','test']]);
    }


    public function test()
    {
        return view('test');
    }
}
