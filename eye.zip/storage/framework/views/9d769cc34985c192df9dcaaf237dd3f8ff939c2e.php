<?php $__env->startSection('main-content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/styles/vendor/toastr.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/styles/vendor/datatables.min.css')); ?>">
           <div class="breadcrumb">
                <h1>Dashboard</h1>
                <ul>
                    <li><a href="">Dashboard</a></li>
                    
                </ul>
            </div>


            <div class="separator-breadcrumb border-top"></div>

            <div class="row">
                <!-- ICON BG -->
                <div class="col-lg-3 col-md-6 col-sm-6">    
                    <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4">
                        <div class="card-body text-center">
                            <i class="i-File-Chart"></i>
                            <div class="content">
                                <p class="text-muted mt-2 mb-0">Total Feedback</p><?php $totalfeedback=App\riview::select('name')->get();   ?>
                                <p id="number" class="text-primary text-24 line-height-1 mb-2"><?php echo e(count($totalfeedback)); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                

            </div>

            <div  style="display: none;" id="table" class="row mb-4">
                <div class="col-md-12 mb-4">
                    <div class="card text-left">

                        <div class="card-body">
                            <h4 class="card-title mb-3">Total Feedbacks</h4>
                            
                            <div class="table-responsive">
                                <table id="zero_configuration_table" class="display table table-striped table-bordered" style="width:100%">
                                 <?php echo $__env->make('datatables.table_content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </table>

                            </div>

                        </div>
                    </div>
                </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
     <script src="<?php echo e(asset('assets/js/vendor/echarts.min.js')); ?>"></script>
     <script src="<?php echo e(asset('assets/js/es5/echart.options.min.js')); ?>"></script>
     <script src="<?php echo e(asset('assets/js/es5/dashboard.v1.script.js')); ?>"></script>
             <script src="<?php echo e(asset('assets/js/vendor/toastr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/toastr.script.js')); ?>"></script>
     <script src="<?php echo e(asset('assets/js/vendor/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatables.script.js')); ?>"></script>

<script type="text/javascript">
    $(document).ready(function(){
        $('#number').click(function(){
            $('#table').show();
            

        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\EyeForte\resources\views/dashboard/dashboardv1.blade.php ENDPATH**/ ?>