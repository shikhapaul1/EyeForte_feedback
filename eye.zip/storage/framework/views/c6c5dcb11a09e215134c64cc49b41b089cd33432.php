<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
     <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>EYE FORTE ™ India&#039;s 1st Brand Exclusive Offline Outlets | Superior Quality Frames, Sunglasses &amp; Contact lenses | Top Quality Complete Eye Care Treatments.</title>
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,400i,600,700,800,900" rel="stylesheet">
<?php echo $__env->yieldContent('before-css'); ?>
    
<link rel="stylesheet" href="<?php echo e(mix('assets/styles/css/themes/lite-purple.min.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('assets/styles/vendor/perfect-scrollbar.css')); ?>">
 
 <?php echo $__env->yieldContent('page-css'); ?>
</head>

<body>
    <div class="app-admin-wrap">

      <?php echo $__env->make('layouts.header-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      



       <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       

        <!-- ============ Body content start ============= -->
        <div class="main-content-wrap sidenav-open d-flex flex-column">

           <?php echo $__env->yieldContent('main-content'); ?>

            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <!-- ============ Body content End ============= -->
    </div>
    <!--=============== End app-admin-wrap ================-->

    <!-- ============ Search UI Start ============= -->
  <?php echo $__env->make('layouts.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ============ Search UI End ============= -->


<script src="<?php echo e(mix('assets/js/common-bundle-script.js')); ?>"></script>
    
    <?php echo $__env->yieldContent('page-js'); ?>

    
    
    <script src="<?php echo e(asset('assets/js/es5/script.min.js')); ?>"></script>

    
    

    <?php echo $__env->yieldContent('bottom-js'); ?>
</body>

</html>
<?php /**PATH E:\xampp\htdocs\EyeForte\resources\views/layouts/master.blade.php ENDPATH**/ ?>