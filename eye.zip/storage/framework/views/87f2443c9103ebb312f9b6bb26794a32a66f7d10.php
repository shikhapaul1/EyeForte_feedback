  <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Email Id</th>
                                            <th>Feedback</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php

                                        $name = App\riview::all();
                                        

                                        ?>
                                        <?php $__currentLoopData = $name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nae): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($nae->name); ?></td>
                                            <td><?php echo e($nae->email); ?></td>
                                            <td><?php echo e($nae->Commentsssss); ?></td>
                                           
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                   <?php /**PATH E:\xampp\htdocs\EyeForte\resources\views/datatables/table_content.blade.php ENDPATH**/ ?>